
/* Code Title: NPC & MONSTER BATTLE ENGINE beta 0.1 - A fight simulation */

/* By: Michael Dixon (c). 04/14/2013 */

/* Objective: Using Struct to build multiple NPCs & Monsters for a battle. */


////////////////////////////////////////////////////////////////////////////////

// npcmon.h - this part of code will be moved in a header file.               //

////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <iostream>
#include <string>
#include <ctime>
#include <stdlib.h>

using namespace std;

//data structure for NPC & Monster Engine

struct npcmon
{
  int npcmon_lev;                        //Set NPC's & Monster's Level. 
  int npcmon_exp;                        //Set NPC's & Monster's Experience.
  int npcmon_hp;                         //Set NPC's & Monster's Hit Points.
  int npcmon_gold;                       //Set NPC's & Monster's Gold.
  int weapon_dmg;                        //Set Weapon Damage.
  int mon_mov;                           //Set Monster's on/off move.
  int npc_mov;                           //Set NPC's on/off move.

  
  string npcmon_name;                    //Set name for NPC & Monster.
  string weapon_name;                    //Set name for Weapon.
  
  bool EndGame;                          //Used for Game loop.
  bool EndBattle;                        //Used for battle loop.
  
  
  void npc_attack();                     //Funcion for Npc's attack.
  void npc_dodge();                      //Function for Npc's dodge.
 
  
  void mon_attack();                     //Funcion for Monster's attack.
  void mon_dodge();                      //Function for Monster's dodge.
 
  
  void npcmon_action();                  //Funtion for NPC's & Mon's action.
  void npcmon_data();                    //Function for NPC's & Mon's data.
  void npcmon_move();                    //Function sets NPC's & Mon's turn.
  void npcmon_selection();               //Function to select a NPC & Mon.
  void npcmon_greet();                   //Function shows welcome screen.
  void npcmon_battle();                  //Function runs the battle.
  void npcmon_show();                    //Function to output battle data.
  void npcmon_clr();                     //Function to clear screen.
  void npcmon_endEng();                    //Function to end Engine. 
};


// Member Selection Operators for NPC & Monster Battle Engine. //

/* NPC */

npcmon fighter;                       //Member for Fighter's data.            
npcmon elf;                           //Member for Elf's data.
npcmon dwarf;                         //Member for Dwarf's data.
npcmon mage;                          //Member for Mage's data.
npcmon knight;                        //Member for Knight's data.
npcmon thief;                         //Member for Thief's data.
npcmon halfling;                      //Member for Halfling's data.
npcmon ranger;                        //Member for Ranger's data.
npcmon druid;                         //Member for Druid's data.
npcmon mystic;                        //Member for Mystic's data

/* Monster */

npcmon dragon;                        //Member for Dragon's data.
npcmon skeleton;                      //Member for Skeleton's data.
npcmon giant;                         //Member for Giant's data.
npcmon cyclops;                       //Member for Cyclop's data.
npcmon beholder;                      //Member for Beholder's data.
npcmon slime;                         //Member for Slime's data.
npcmon werewolf;                      //Member for Werewolf's data.
npcmon vampire;                       //Member for Vampire's data.
npcmon hydra;                         //Member for Hydra's data.
npcmon mummy;                         //Member for Mummy's data.



/* Other Member Selection Operators. */

npcmon npcmonset;                    //Member for functions.
npcmon npc;                          //Member for copying NPC's data.
npcmon mon;                          //Member for copying Monster's data.



//////////////////////////////////////////////////////////////////////////////// 

//npcmon.cpp - this part of code will stay as the main.cpp file.              //

////////////////////////////////////////////////////////////////////////////////


int main(int argc, char *argv[])
{  
  npcmonset.npcmon_greet();
  npcmonset.npcmon_clr();
  
  npcmonset.EndGame = true;
  while (npcmonset.EndGame != false)
  {  
  npcmonset.npcmon_data();
  npcmonset.npcmon_selection();
  npcmonset.npcmon_battle();
  npcmonset.npcmon_endEng();
  }
  
  cout << " Please Wait. . ." << endl << endl;
  Sleep(100);
  
  cout << " End of NPC & MONSTER Battle Engine Beta 0.1" << endl << endl;
 
  system("PAUSE");
  return EXIT_SUCCESS;
 
}



////////////////////////////////////////////////////////////////////////////////

// npcmonfuc.cpp - this part of code will be put in a file for all functions. //

////////////////////////////////////////////////////////////////////////////////


 /* Function npcmon_greet() */   

   void npcmon::npcmon_greet()                   
   {
   
   cout << endl;
   cout << "  NPC & MONSTER BATTLE ENGINE beta 0.1" << endl;
   cout << "  Program By: Michael Dixon (C). 04/14/2013. " << endl << endl;
   cout << "  This program selects one monster and one npc" << endl;
   cout << "  for a fight simulation." << endl << endl;
   
   system("PAUSE");
   
   }
   
 /* Function npcmon_data() */

   void npcmon::npcmon_data()
 {
       
  // NPCs //
 
  fighter.npcmon_lev = 3;
  fighter.npcmon_exp = 4000;
  fighter.npcmon_hp = 82;
  fighter.weapon_dmg = 10;  
  fighter.npcmon_gold = 450;
  
  fighter.npcmon_name = "Fighter";
  fighter.weapon_name = "Bastard Sword - Two Handed"; 
  
  elf.npcmon_lev = 7;
  elf.npcmon_exp = 120000;
  elf.npcmon_hp = 116;
  elf.weapon_dmg = 18;  
  elf.npcmon_gold = 3000;
  
  elf.npcmon_name = "Elf";
  elf.weapon_name = "Magical Crossbow - Hvy"; 
 
  dwarf.npcmon_lev = 12;
  dwarf.npcmon_exp = 660000;
  dwarf.npcmon_hp = 280;
  dwarf.weapon_dmg = 14;  
  dwarf.npcmon_gold = 4800;
  
  dwarf.npcmon_name = "Dwarf";
  dwarf.weapon_name = "1 Hand Axe & 1 Battle Axe"; 
 
  mage.npcmon_lev = 17;
  mage.npcmon_exp = 1350000;
  mage.npcmon_hp = 175;
  mage.weapon_dmg = 18;  
  mage.npcmon_gold = 9000;
  
  mage.npcmon_name = "Mage";
  mage.weapon_name = "Magic Missiles"; 

  knight.npcmon_lev = 10;
  knight.npcmon_exp = 360000;
  knight.npcmon_hp = 110;
  knight.weapon_dmg = 8;  
  knight.npcmon_gold = 600;
  
  knight.npcmon_name = "Knight";
  knight.weapon_name = "Normal Sword";  
 
  thief.npcmon_lev = 5;
  thief.npcmon_exp = 9600;
  thief.npcmon_hp = 45;
  thief.weapon_dmg = 6;  
  thief.npcmon_gold = 6000;
  
  thief.npcmon_name = "Thief";
  thief.weapon_name = "Short Sword"; 
  
  halfling.npcmon_lev = 8;
  halfling.npcmon_exp = 120000;
  halfling.npcmon_hp = 72;
  halfling.weapon_dmg = 6;  
  halfling.npcmon_gold = 900;
  
  halfling.npcmon_name = "Halfling";
  halfling.weapon_name = "Short Bow"; 
 
  ranger.npcmon_lev = 1;
  ranger.npcmon_exp = 4000;
  ranger.npcmon_hp = 20;
  ranger.weapon_dmg = 3;  
  ranger.npcmon_gold = 100;
  
  ranger.npcmon_name = "Ranger";
  ranger.weapon_name = "Light Sword"; 
  
  druid.npcmon_lev = 12;
  druid.npcmon_exp = 500000;
  druid.npcmon_hp = 108;
  druid.weapon_dmg = 9;  
  druid.npcmon_gold = 250;
  
  druid.npcmon_name = "Druid";
  druid.weapon_name = "Staff"; 
  
  mystic.npcmon_lev = 16;
  mystic.npcmon_exp = 1080000;
  mystic.npcmon_hp = 190;
  mystic.weapon_dmg = 20;  
  mystic.npcmon_gold = 600;
  
  mystic.npcmon_name = "Mystic";
  mystic.weapon_name = "War Hammer"; 
 
 
  // Monsters //
 
  dragon.npcmon_lev = 4;
  dragon.npcmon_exp = 6300;
  dragon.npcmon_hp = 240;
  dragon.weapon_dmg = 30;  
  dragon.npcmon_gold = 800000;
  
  dragon.npcmon_name = "Dragon";
  dragon.weapon_name = "Breath of Fire"; 
  
  skeleton.npcmon_lev = 1;
  skeleton.npcmon_exp = 250;
  skeleton.npcmon_hp = 20;
  skeleton.weapon_dmg = 4;  
  skeleton.npcmon_gold =2;
  
  skeleton.npcmon_name = "Skeleton";
  skeleton.weapon_name = "Rusty Sword"; 
 
  giant.npcmon_lev = 3;
  giant.npcmon_exp = 720;
  giant.npcmon_hp = 90;
  giant.weapon_dmg = 18;  
  giant.npcmon_gold = 5000;
  
  giant.npcmon_name = "Giant";
  giant.weapon_name = "Boulder"; 
 
  cyclops.npcmon_lev = 6;
  cyclops.npcmon_exp = 9500;
  cyclops.npcmon_hp = 109;
  cyclops.weapon_dmg = 24;  
  cyclops.npcmon_gold = 80000;
  
  cyclops.npcmon_name = "Cyclops";
  cyclops.weapon_name = "Large Stone Axe"; 
  
  beholder.npcmon_lev = 4;
  beholder.npcmon_exp = 14975;
  beholder.npcmon_hp = 80;
  beholder.weapon_dmg = 16;  
  beholder.npcmon_gold = 400;
  
  beholder.npcmon_name = "Beholder";
  beholder.weapon_name = "Magic Eyes";
  
  slime.npcmon_lev = 1;
  slime.npcmon_exp = 200;
  slime.npcmon_hp = 10;
  slime.weapon_dmg = 4;  
  slime.npcmon_gold = 3;
  
  slime.npcmon_name = "Slime";
  slime.weapon_name = "Body Attack";  
 
  werewolf.npcmon_lev = 8;
  werewolf.npcmon_exp = 20000;
  werewolf.npcmon_hp = 40;
  werewolf.weapon_dmg = 10;  
  werewolf.npcmon_gold = 30;
  
  werewolf.npcmon_name = "Werewolf";
  werewolf.weapon_name = "Claws"; 
 
  vampire.npcmon_lev = 2;
  vampire.npcmon_exp = 1500;
  vampire.npcmon_hp = 96;
  vampire.weapon_dmg = 13;  
  vampire.npcmon_gold = 4000;
  
  vampire.npcmon_name = "Vampire";
  vampire.weapon_name = "Hand Combat"; 
  
  hydra.npcmon_lev = 7;
  hydra.npcmon_exp = 200000;
  hydra.npcmon_hp = 210;
  hydra.weapon_dmg = 14;  
  hydra.npcmon_gold = 9000;
  
  hydra.npcmon_name = "Hydra";
  hydra.weapon_name = "Bite"; 
  
  mummy.npcmon_lev = 3;
  mummy.npcmon_exp = 500;
  mummy.npcmon_hp = 40;
  mummy.weapon_dmg = 4;  
  mummy.npcmon_gold = 16;
  
  mummy.npcmon_name = "Mummy";
  mummy.weapon_name = "Hand Combat"; 
 }
 
 
 /* Function npcmon_selection() */

   void npcmon::npcmon_selection()               
   {

   srand(time(0));
   
   int randomNumber1 = rand();
   int randomNumber2 = rand();
   int dieOne = (randomNumber1 % 10) + 1;
   int dieTwo = (randomNumber2 % 10) + 1;
   
   if (dieOne == 1) npc = fighter;
   if (dieOne == 2) npc = elf;
   if (dieOne == 3) npc = dwarf;
   if (dieOne == 4) npc = mage;
   if (dieOne == 5) npc = knight;
   if (dieOne == 6) npc = halfling;
   if (dieOne == 7) npc = ranger;
   if (dieOne == 8) npc = thief;
   if (dieOne == 9) npc = druid;
   if (dieOne == 10) npc = mystic;
   
   if (dieTwo == 1) mon = dragon;
   if (dieTwo == 2) mon = skeleton;
   if (dieTwo == 3) mon = giant;
   if (dieTwo == 4) mon = cyclops;
   if (dieTwo == 5) mon = beholder;
   if (dieTwo == 6) mon = slime;
   if (dieTwo == 7) mon = werewolf;
   if (dieTwo == 8) mon = vampire;
   if (dieTwo == 9) mon = hydra;
   if (dieTwo == 10) mon = mummy;   
  
   mon.npcmon_show();
   npc.npcmon_show();

   }
   

 /* Function npcmon_battle() */   

   void npcmon::npcmon_battle() 
   {
    system("pause");
    Sleep(600);
    npcmon_clr();
    
    EndBattle = true;
    while (EndBattle != false)
    {
     npcmon_move();      
     npcmon_action();
     
     if (mon.npcmon_hp <= 0)
     {
      mon.npcmon_hp = 0;                 
      EndBattle = false;
     }
     if (npc.npcmon_hp <= 0)
    {
     npc.npcmon_hp = 0;                 
     EndBattle = false;
    }
    
    }
   }
   
   
 /* Function npcmon_move() */

   void npcmon::npcmon_move()
   {
    srand(time(0));
    
    int randomNumber = rand();
    
    int die = (randomNumber % 2) + 1;
    
    if (die == 1) mon_mov = 1;
    if (die == 2) npc_mov = 1; 
   }
    
   

 /* Function npcmon_action() */

  void npcmon::npcmon_action()
 {
  srand(time(0));
  
  int randomNumber1 = rand();
  int randomNumber2 = rand();
  
  int die1 = (randomNumber1 % 2) + 1;
  int die2 = (randomNumber2 % 2) + 1;
  
  if (mon_mov == 1)
  {
   switch(die1)
   {
    case 1: mon_attack();
    case 2: mon_dodge();
   }
   
    if (npc_mov == 1)
  {
   switch(die2)
   {
    case 1: npc_attack();
    case 2: npc_dodge();
   }
   
  } 
   
  } 
 }
 


 /* Group of Functions for npcmon_action() Function */

 // Monsters //
 
  void npcmon::mon_attack() 
  {
  
   npc.npcmon_hp = npc.npcmon_hp - mon.weapon_dmg;
   
   cout << mon.npcmon_name << " attacks and caused " << mon.weapon_dmg 
   << " HP of DMG to " << npc.npcmon_name << "." << endl; 
   
  
   cout << npc.npcmon_name << " has " << npc.npcmon_hp << " HP. " << endl << endl;
    
   Sleep(3000);
   npcmon_clr();
  }
  
  void npcmon::mon_dodge() 
  {

  int holdNum = 3;
  
  mon.npcmon_hp = mon.npcmon_hp - holdNum;
  cout << npc.npcmon_name << " dodged " << mon.npcmon_name << " attack. " 
  << endl;
  
  cout << mon.npcmon_name << " takes " << holdNum <<  " HP of DMG. " << endl;
  
  cout << mon.npcmon_name << " now has " << mon.npcmon_hp 
  << " HP. " << endl << endl;
  
  Sleep(3000);
  npcmon_clr();
  } 
  

 // NPCs //
 
 void npcmon::npc_attack() 
  {
   mon.npcmon_hp = mon.npcmon_hp - npc.weapon_dmg;
   
   cout << npc.npcmon_name << " attacks and caused " << npc.weapon_dmg 
   << " HP of DMG to " << mon.npcmon_name << "." << endl; 
   
  
   cout << mon.npcmon_name << " has " << mon.npcmon_hp  
   << " HP. " << endl << endl;
   
   Sleep(3000);
   npcmon_clr();
  } 
 
  void npcmon::npc_dodge() 
  {
   int holdNum = 1;
   
   npc.npcmon_hp = npc.npcmon_hp - holdNum;
   cout << mon.npcmon_name << " dodged " << npc.npcmon_name << " attack. " 
   << endl;
  
   cout << npc.npcmon_name << " takes " << holdNum <<  " HP of DMG. " << endl;
  
   cout << npc.npcmon_name << " now has " << npc.npcmon_hp 
   << " hit points left. " << endl << endl;
    
   Sleep(3000);
   npcmon_clr();
  } 
  

 /* Functions for npcmon_show() */
  
  void npcmon::npcmon_show()
 {
  cout << endl << "   " << npcmon_name << "  Lev: " << npcmon_lev 
  << endl << endl;
   
  cout << "   HP:  " << npcmon_hp << endl;
  cout << "   EXP: " << npcmon_exp << endl;
  cout << "   GLD: " <<npcmon_gold << endl << endl;
  
  cout << "   WEAPON: " << weapon_name << " (DMG = " << weapon_dmg << ")" 
  << endl << endl;                                           
  
  }   


 /* Function npcmon_clr() */   

   void npcmon::npcmon_clr()  
   {   
    system("cls");
   }


 /* Function npcmon_endEng() */    
   
   void npcmon::npcmon_endEng()  
   {
    if (mon.npcmon_hp == 0)
    {
     cout << npc.npcmon_name << " won the battle." << endl << endl;
    }       
    
    if (npc.npcmon_hp == 0)
    {
     cout << mon.npcmon_name << " won the battle." << endl << endl;
    }
    
    cout << "The computer will make a choice to play again or quit." << endl 
    << endl;
    
    system ("PAUSE");
    
    srand(time(0));
    
    int randomNumber = rand();
    int die = (randomNumber % 2) + 1;
    
    if (die == 1)
    {
     cout << endl << "The computer chose to play again." << endl << endl;
     Sleep(3000);
     npcmon_clr();
    }
    
    if (die == 2)
    {
     cout << endl << "The computer chose to quit the program." << endl << endl;
     Sleep(2000);
     npcmonset.EndGame = false;
    }
   }
